python /content/IPM_GNN_CODE/verify_ipm_dyglib.py && python /content/IPM_GNN_CODE/run_ipm_official_gnns.py --quick --out_dir /content/drive/MyDrive/IPM/IPM_GNN_RESULTS
