#!/usr/bin/env python
import os, sys, json, math, argparse, random, time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.metrics import average_precision_score, roc_auc_score

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--dyglib_dir", default="/content/DyGLib")
    p.add_argument("--data_dir", default="/content/IPM_DATA")
    p.add_argument("--out_dir", default="/content/drive/MyDrive/IPM/IPM_GNN_RESULTS")
    p.add_argument("--models", nargs="+", default=["TGAT","TGN","GraphMixer","DyGFormer"])
    p.add_argument("--seeds", nargs="+", type=int, default=[0,1,2,3,4])
    p.add_argument("--epochs", type=int, default=5)
    p.add_argument("--batch_size", type=int, default=512)
    p.add_argument("--tgn_batch_size", type=int, default=200)
    p.add_argument("--num_neighbors", type=int, default=20)
    p.add_argument("--node_feat_dim", type=int, default=64)
    p.add_argument("--edge_feat_dim", type=int, default=32)
    p.add_argument("--time_feat_dim", type=int, default=100)
    p.add_argument("--hidden_dim", type=int, default=64)
    p.add_argument("--lr", type=float, default=1e-4)
    p.add_argument("--weight_decay", type=float, default=1e-5)
    p.add_argument("--dropout", type=float, default=0.1)
    p.add_argument("--time_gap", type=int, default=2000)
    p.add_argument("--max_seq_len", type=int, default=32)
    p.add_argument("--quick", action="store_true")
    return p.parse_args()

args = parse_args()
sys.path.insert(0, args.dyglib_dir)

from utils.DataLoader import Data
from utils.utils import get_neighbor_sampler, set_random_seed
from models.TGAT import TGAT
from models.MemoryModel import MemoryModel, compute_src_dst_node_time_shifts
from models.GraphMixer import GraphMixer
from models.DyGFormer import DyGFormer
from models.modules import MergeLayer

DEVICE = "cuda:0" if torch.cuda.is_available() else "cpu"
print("device:", DEVICE)
if not torch.cuda.is_available():
    raise RuntimeError("CUDA GPU not available. In Colab choose 代码执行程序 → 更改运行时类型 → T4 GPU.")

DATA_DIR = Path(args.data_dir)
OUT_DIR = Path(args.out_dir)
OUT_DIR.mkdir(parents=True, exist_ok=True)

SCRIPT_VERSION = "v3_tgn_optimizer_fix"
TRAIN_END_TS = pd.Timestamp("2018-01-01 00:00:00", tz="Asia/Shanghai").timestamp()

raw = pd.read_csv(DATA_DIR/"ipm_temporal_raw.csv.gz")
q = pd.read_csv(DATA_DIR/"ipm_labeled_queries.csv.gz")
groups = pd.read_csv(DATA_DIR/"timestamp_groups.csv.gz")

# ----- frozen checks -----
assert len(raw) == 994890, len(raw)
assert {"u","i","ts","label","feat0"}.issubset(raw.columns)
assert {"edge_id","u","i","year","main_label","split"}.issubset(q.columns)
assert q["edge_id"].between(1, len(raw)).all()
assert (q.loc[q.split=="train","year"].between(2016,2017)).all()
assert (q.loc[q.split=="test","year"].between(2018,2019)).all()

num_media = int(raw.u.max()) + 1
num_view = int(raw.i.max()) + 1

# DyGLib node ids are 1-based and the bipartite sides must not overlap.
src = raw.u.to_numpy(np.int64) + 1
dst = raw.i.to_numpy(np.int64) + 1 + num_media
ts = raw.ts.to_numpy(np.float64)
edge_ids = np.arange(1, len(raw)+1, dtype=np.int64)
dummy_labels = np.zeros(len(raw), dtype=np.float32)

# Query rows are keyed by canonical edge_id.
q = q.copy()
q["src"] = q.u.astype(np.int64) + 1
q["dst"] = q.i.astype(np.int64) + 1 + num_media
q["ts_sec"] = q.timestamp_ms.astype(np.float64) / 1000.0
q["label_y"] = q.main_label.astype(np.float32)

train_q = q[q.split=="train"].sort_values(["timestamp_ms","edge_id"]).reset_index(drop=True)
test_q = q[q.split=="test"].sort_values(["timestamp_ms","edge_id"]).reset_index(drop=True)

if args.quick:
    # deterministic smoke subset; the graph history remains full.
    train_q = train_q.iloc[:min(20000, len(train_q))].copy()
    test_q = test_q.iloc[:min(20000, len(test_q))].copy()
    args.epochs = 1
    args.seeds = args.seeds[:1]
    print("QUICK MODE:", len(train_q), len(test_q), "queries")

full_data = Data(src_node_ids=src, dst_node_ids=dst, node_interact_times=ts,
                 edge_ids=edge_ids, labels=dummy_labels)
sampler = get_neighbor_sampler(data=full_data, sample_neighbor_strategy="recent", seed=1)

num_nodes = max(src.max(), dst.max()) + 1
# Fixed zero raw features = structure/time-only temporal-GNN baseline.
node_feats = np.zeros((num_nodes, args.node_feat_dim), dtype=np.float32)
edge_feats = np.zeros((len(raw)+1, args.edge_feat_dim), dtype=np.float32)

class PairHead(nn.Module):
    def __init__(self, dim, dropout):
        super().__init__()
        # DyGLib's own MergeLayer is retained as the task head.
        self.merge = MergeLayer(input_dim1=dim, input_dim2=dim,
                                hidden_dim=dim, output_dim=1)
        self.dropout = nn.Dropout(dropout)
    def forward(self, a, b):
        return self.merge(self.dropout(a), self.dropout(b)).squeeze(-1)

def get_metrics(y, p):
    y = np.asarray(y)
    p = np.asarray(p)
    ap = average_precision_score(y, p)
    roc = roc_auc_score(y, p)
    k = max(1, int(math.ceil(0.05 * len(y))))
    idx = np.argpartition(-p, k-1)[:k]
    tp = y[idx].sum()
    precision = float(tp / k)
    recall = float(tp / max(1, y.sum()))
    base = float(y.mean())
    lift = precision / base if base > 0 else float("nan")
    return {
        "PR_AUC": float(ap), "ROC_AUC": float(roc),
        "Precision_at_5pct": precision, "Recall_at_5pct": recall,
        "Lift_at_5pct": float(lift), "N": int(len(y)),
        "positives": int(y.sum()), "base_rate": base
    }

def make_backbone(name):
    if name == "TGAT":
        m = TGAT(node_raw_features=node_feats, edge_raw_features=edge_feats,
                 neighbor_sampler=sampler, time_feat_dim=args.time_feat_dim,
                 num_layers=2, num_heads=2, dropout=args.dropout, device=DEVICE)
    elif name == "GraphMixer":
        m = GraphMixer(node_raw_features=node_feats, edge_raw_features=edge_feats,
                       neighbor_sampler=sampler, time_feat_dim=args.time_feat_dim,
                       num_tokens=args.num_neighbors, num_layers=2,
                       dropout=args.dropout, device=DEVICE)
    elif name == "DyGFormer":
        m = DyGFormer(node_raw_features=node_feats, edge_raw_features=edge_feats,
                      neighbor_sampler=sampler, time_feat_dim=args.time_feat_dim,
                      channel_embedding_dim=50, patch_size=1,
                      num_layers=2, num_heads=2, dropout=args.dropout,
                      max_input_sequence_length=args.max_seq_len, device=DEVICE)
    elif name == "TGN":
        # Official DyGLib time-shift normalization based on interactions visible by end-2017.
        # Frozen split boundary: start of 2018 in the study's China-local calendar.
        # Use all canonical interactions strictly before the boundary, including unlabeled history.
        mask = ts < TRAIN_END_TS
        a,b,c,d = compute_src_dst_node_time_shifts(src[mask], dst[mask], ts[mask])
        m = MemoryModel(node_raw_features=node_feats, edge_raw_features=edge_feats,
                        neighbor_sampler=sampler, time_feat_dim=args.time_feat_dim,
                        model_name="TGN", num_layers=2, num_heads=2,
                        dropout=args.dropout,
                        src_node_mean_time_shift=a, src_node_std_time_shift=b,
                        dst_node_mean_time_shift_dst=c, dst_node_std_time_shift=d,
                        device=DEVICE)
    else:
        raise ValueError(name)
    return m.to(DEVICE)

def embeddings_nonmemory(model_name, backbone, df):
    u = df.src.to_numpy(np.int64)
    v = df.dst.to_numpy(np.int64)
    t = df.ts_sec.to_numpy(np.float64)
    if model_name == "TGAT":
        return backbone.compute_src_dst_node_temporal_embeddings(
            src_node_ids=u, dst_node_ids=v, node_interact_times=t,
            num_neighbors=args.num_neighbors)
    elif model_name == "GraphMixer":
        return backbone.compute_src_dst_node_temporal_embeddings(
            src_node_ids=u, dst_node_ids=v, node_interact_times=t,
            num_neighbors=args.num_neighbors, time_gap=args.time_gap)
    elif model_name == "DyGFormer":
        return backbone.compute_src_dst_node_temporal_embeddings(
            src_node_ids=u, dst_node_ids=v, node_interact_times=t)
    else:
        raise ValueError(model_name)

def batched_df(df, bs):
    for a in range(0, len(df), bs):
        yield df.iloc[a:a+bs]

def train_nonmemory(name, seed):
    set_random_seed(seed)
    backbone = make_backbone(name)
    head = PairHead(args.node_feat_dim, args.dropout).to(DEVICE)
    opt = torch.optim.Adam(list(backbone.parameters())+list(head.parameters()),
                           lr=args.lr, weight_decay=args.weight_decay)
    y_train = train_q.label_y.to_numpy(np.float32)
    posw = float((len(y_train)-y_train.sum()) / max(1.0, y_train.sum()))
    loss_fn = nn.BCEWithLogitsLoss(pos_weight=torch.tensor(posw, device=DEVICE))

    for epoch in range(args.epochs):
        backbone.train(); head.train()
        losses=[]
        # chronological, no shuffling; every neighbor query is strictly < its timestamp in DyGLib.
        for bi,b in enumerate(batched_df(train_q, args.batch_size),1):
            s,d = embeddings_nonmemory(name, backbone, b)
            logits = head(s,d)
            y = torch.tensor(b.label_y.to_numpy(np.float32), device=DEVICE)
            loss = loss_fn(logits, y)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(list(backbone.parameters())+list(head.parameters()), 1.0)
            opt.step()
            losses.append(float(loss.detach().cpu()))
            if bi % 100 == 0:
                print(name, "seed", seed, "epoch", epoch+1, "batch", bi, "loss", np.mean(losses[-100:]))

    backbone.eval(); head.eval()
    probs=[]; ys=[]; ids=[]
    with torch.no_grad():
        for b in batched_df(test_q, args.batch_size):
            s,d = embeddings_nonmemory(name, backbone, b)
            p = torch.sigmoid(head(s,d)).cpu().numpy()
            probs.extend(p.tolist()); ys.extend(b.label_y.tolist()); ids.extend(b.edge_id.tolist())
    return backbone, head, np.asarray(ids), np.asarray(ys), np.asarray(probs)

def aligned_stream_batches(end_edge_id, max_bs):
    # Batch canonical interactions chronologically but never split a timestamp tie group.
    g = groups[groups.first_edge_id <= end_edge_id]
    current=[]
    n=0
    for row in g.itertuples(index=False):
        lo=int(row.first_edge_id); hi=min(int(row.last_edge_id), end_edge_id)
        if hi < lo: continue
        size=hi-lo+1
        if current and n+size > max_bs:
            yield current
            current=[]; n=0
        current.append((lo,hi)); n += size
    if current:
        yield current

def flatten_ranges(ranges):
    # contiguous by construction
    lo=ranges[0][0]; hi=ranges[-1][1]
    return lo,hi

def get_tgn_trainable_params(backbone, head):
    # DyGLib stores memory state as nn.Parameter(requires_grad=False) so it can be
    # checkpointed with the model. These state tensors must not be passed to Adam
    # or gradient clipping after in-place memory updates. Optimize only genuine
    # learnable parameters plus the task head.
    params = [p for n, p in backbone.named_parameters()
              if p.requires_grad and not n.startswith("memory_bank.")]
    params += [p for p in head.parameters() if p.requires_grad]
    if not params:
        raise RuntimeError("No trainable TGN parameters found")
    return params

def train_tgn(seed):
    set_random_seed(seed)
    backbone = make_backbone("TGN")
    head = PairHead(args.node_feat_dim, args.dropout).to(DEVICE)
    tgn_trainable_params = get_tgn_trainable_params(backbone, head)
    opt = torch.optim.Adam(tgn_trainable_params,
                           lr=args.lr, weight_decay=args.weight_decay)
    print("TGN trainable parameter tensors:", len(tgn_trainable_params))
    y_train = train_q.label_y.to_numpy(np.float32)
    posw = float((len(y_train)-y_train.sum()) / max(1.0, y_train.sum()))
    loss_fn = nn.BCEWithLogitsLoss(pos_weight=torch.tensor(posw, device=DEVICE))

    train_map = dict(zip(train_q.edge_id.astype(int), train_q.label_y.astype(float)))
    end_train_edge = int(np.searchsorted(ts, TRAIN_END_TS, side="left"))
    assert end_train_edge == int(train_q.edge_id.max()), (end_train_edge, int(train_q.edge_id.max()))

    def replay_train(do_opt=True):
        backbone.memory_bank.__init_memory_bank__()
        losses=[]
        for bi,ranges in enumerate(aligned_stream_batches(end_train_edge, args.tgn_batch_size),1):
            lo,hi=flatten_ranges(ranges)
            sl=slice(lo-1,hi)
            su=src[sl]; sv=dst[sl]; st=ts[sl]; se=edge_ids[sl]
            s_emb,d_emb = backbone.compute_src_dst_node_temporal_embeddings(
                src_node_ids=su, dst_node_ids=sv, node_interact_times=st,
                edge_ids=se, edges_are_positive=True, num_neighbors=args.num_neighbors)
            mask=np.array([int(e) in train_map for e in se], dtype=bool)
            if do_opt and mask.any():
                ix=torch.from_numpy(np.where(mask)[0]).long().to(DEVICE)
                logits=head(s_emb[ix], d_emb[ix])
                yy=torch.tensor([train_map[int(e)] for e in se[mask]], dtype=torch.float32, device=DEVICE)
                loss=loss_fn(logits,yy)
                opt.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(tgn_trainable_params, 1.0)
                opt.step()
                losses.append(float(loss.detach().cpu()))
            backbone.memory_bank.detach_memory_bank()
            if bi % 500 == 0:
                print("TGN seed",seed,"batch",bi,"loss",np.mean(losses[-100:]) if losses else None)
        return losses

    for epoch in range(args.epochs):
        backbone.train(); head.train()
        losses=replay_train(do_opt=True)
        print("TGN seed",seed,"epoch",epoch+1,"mean loss",np.mean(losses) if losses else None)

    # Consistent memory replay with final weights through end-2017.
    backbone.eval(); head.eval()
    with torch.no_grad():
        replay_train(do_opt=False)

    test_map = dict(zip(test_q.edge_id.astype(int), test_q.label_y.astype(float)))
    test_edge_set=set(test_map.keys())
    end_test_edge=int(test_q.edge_id.max())
    probs=[]; ys=[]; ids=[]
    start_edge=end_train_edge+1
    with torch.no_grad():
        # Process all 2018–2019 interactions, not only labeled queries, to update memory/history.
        all_batches=list(aligned_stream_batches(end_test_edge, args.tgn_batch_size))
        for bi,ranges in enumerate(all_batches,1):
            lo,hi=flatten_ranges(ranges)
            if hi < start_edge: 
                continue
            lo=max(lo,start_edge)
            sl=slice(lo-1,hi)
            su=src[sl]; sv=dst[sl]; st=ts[sl]; se=edge_ids[sl]
            s_emb,d_emb=backbone.compute_src_dst_node_temporal_embeddings(
                src_node_ids=su,dst_node_ids=sv,node_interact_times=st,
                edge_ids=se,edges_are_positive=True,num_neighbors=args.num_neighbors)
            mask=np.array([int(e) in test_edge_set for e in se],dtype=bool)
            if mask.any():
                ix=torch.from_numpy(np.where(mask)[0]).long().to(DEVICE)
                pp=torch.sigmoid(head(s_emb[ix],d_emb[ix])).cpu().numpy()
                ee=se[mask]
                probs.extend(pp.tolist())
                ids.extend(ee.tolist())
                ys.extend([test_map[int(e)] for e in ee])
            backbone.memory_bank.detach_memory_bank()
            if bi % 1000 == 0:
                print("TGN test batch",bi,"predictions",len(probs))
    # sort to edge id for reproducible output
    o=np.argsort(ids)
    return backbone,head,np.asarray(ids)[o],np.asarray(ys)[o],np.asarray(probs)[o]

def run_one(name, seed):
    print("\n====",name,"seed",seed,"====")
    t0=time.time()
    if name=="TGN":
        _,_,ids,y,p=train_tgn(seed)
    else:
        _,_,ids,y,p=train_nonmemory(name,seed)
    met=get_metrics(y,p)
    met.update({"model":name,"seed":seed,"seconds":time.time()-t0,
                "quick":bool(args.quick),
                "dyglib_commit":"3aacc36b94b8d2d8293d70a74fdf6d39089b4163",
                "feature_protocol":"zero raw node/edge features; structure/time-only",
                "split":"2016-2017 train; 2018-2019 test",
                "script_version":SCRIPT_VERSION,
                "tgn_optimizer_protocol":"exclude memory state; optimize requires_grad learnable TGN parameters + pair head" if name=="TGN" else "standard end-to-end learnable parameters + pair head"})
    print(json.dumps(met,indent=2))
    stem=f"{name}_seed{seed}" + ("_QUICK" if args.quick else "")
    pd.DataFrame({"edge_id":ids,"label":y,"prob":p}).to_csv(OUT_DIR/f"{stem}_predictions.csv.gz",index=False,compression="gzip")
    with open(OUT_DIR/f"{stem}_metrics.json","w") as f: json.dump(met,f,indent=2)
    torch.cuda.empty_cache()
    return met

all_metrics=[]
for name in args.models:
    if name not in {"TGAT","TGN","GraphMixer","DyGFormer"}:
        raise ValueError(name)
    for seed in args.seeds:
        all_metrics.append(run_one(name,seed))

pd.DataFrame(all_metrics).to_csv(OUT_DIR/("metrics_QUICK.csv" if args.quick else "metrics_all_seeds.csv"),index=False)

if not args.quick:
    df=pd.DataFrame(all_metrics)
    summary=df.groupby("model").agg(
        PR_AUC_mean=("PR_AUC","mean"), PR_AUC_sd=("PR_AUC","std"),
        ROC_AUC_mean=("ROC_AUC","mean"), ROC_AUC_sd=("ROC_AUC","std"),
        Precision5_mean=("Precision_at_5pct","mean"),
        Recall5_mean=("Recall_at_5pct","mean"),
        Lift5_mean=("Lift_at_5pct","mean")
    ).reset_index()
    summary.to_csv(OUT_DIR/"metrics_summary.csv",index=False)
    print("\n=== SUMMARY ===")
    print(summary.to_string(index=False))
print("\nSaved to",OUT_DIR)
