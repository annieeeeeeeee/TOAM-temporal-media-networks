python /content/IPM_GNN_CODE/run_ipm_official_gnns.py --epochs 5 --out_dir /content/drive/MyDrive/IPM/IPM_GNN_RESULTS
