#!/usr/bin/env python
import os, sys, json
from pathlib import Path
import pandas as pd
import torch

DYGLIB="/content/DyGLib"
DATA="/content/IPM_DATA"
sys.path.insert(0,DYGLIB)

print("PyTorch:",torch.__version__)
print("CUDA:",torch.cuda.is_available(),torch.cuda.get_device_name(0) if torch.cuda.is_available() else "")
assert torch.cuda.is_available()
assert Path(DYGLIB,"models","TGAT.py").exists()
assert Path(DYGLIB,"models","GraphMixer.py").exists()
assert Path(DYGLIB,"models","DyGFormer.py").exists()
assert Path(DYGLIB,"models","MemoryModel.py").exists()

raw=pd.read_csv(Path(DATA,"ipm_temporal_raw.csv.gz"))
q=pd.read_csv(Path(DATA,"ipm_labeled_queries.csv.gz"))
g=pd.read_csv(Path(DATA,"timestamp_groups.csv.gz"))
print("interactions:",len(raw))
print("queries:",len(q))
print("train:",(q.split=="train").sum())
print("test:",(q.split=="test").sum())
print("timestamp groups:",len(g),"max tie:",g.n_interactions.max())
assert len(raw)==994890
assert (q.split=="train").sum()==345430
assert (q.split=="test").sum()==299724
print("VERIFY OK")
