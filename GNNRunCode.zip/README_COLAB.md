# IP&M — DyGLib official-code temporal GNN baseline bundle (v2)

## What this does
Uses the frozen DyGLib commit:
`3aacc36b94b8d2d8293d70a74fdf6d39089b4163`

Architectures:
- TGAT
- TGN
- GraphMixer
- DyGFormer

Study split:
- train: 2016–2017
- test: 2018–2019

Task:
- episode-level EA classification
- main label: 3h, EA>=2 from the supplied adapter package

Metrics:
- PR-AUC (primary)
- ROC-AUC
- Precision@5%
- Recall@5%
- Lift@5%

## Baseline feature protocol
This is the **structure/time-only** official-code architecture baseline:
raw node and edge features are zero-initialized.
No Propensity, Prestige, system-network features, or cross-platform engineered features are fed to the GNN.

## Leakage protocol
DyGLib historical neighbor queries use interactions before the query time.
For TGN, temporal batches never split an identical timestamp group. Messages produced in a batch are applied only in a later batch, so no same-timestamp interaction can update memory before another member of that tie group is scored. Batching can delay some allowed past updates; it never introduces future/tie information.

## Colab steps
Assumes:
- DyGLib cloned to `/content/DyGLib`
- IPM adapter unzipped to `/content/IPM_DATA`
- Google Drive mounted

Upload this bundle to Colab or unzip it to `/content/IPM_GNN_CODE`.

### 1. Verify
`!python /content/IPM_GNN_CODE/verify_ipm_dyglib.py`

### 2. Smoke test (1 seed, 1 epoch, first 20k train/test queries)
`!python /content/IPM_GNN_CODE/run_ipm_official_gnns.py --quick --out_dir /content/drive/MyDrive/IPM/IPM_GNN_RESULTS`

### 3. Full run (4 models × 5 seeds)
`!python /content/IPM_GNN_CODE/run_ipm_official_gnns.py --epochs 5 --out_dir /content/drive/MyDrive/IPM/IPM_GNN_RESULTS`

If GPU memory is insufficient for DyGFormer, rerun only it with smaller settings:
`!python /content/IPM_GNN_CODE/run_ipm_official_gnns.py --models DyGFormer --seeds 0 1 2 3 4 --epochs 5 --batch_size 128 --max_seq_len 16 --out_dir /content/drive/MyDrive/IPM/IPM_GNN_RESULTS`

## Important manuscript wording
These are **DyGLib official-code architecture baselines adapted to the paper's episode-classification task and frozen temporal split**.
Do not describe them as an unmodified DyGLib benchmark protocol, because the task-specific classification head and split are necessarily adapted.

## v3 correction (TGN)
- Excludes DyGLib memory-state Parameters (`memory_bank.*`, which are non-trainable state with `requires_grad=False`) from Adam and gradient clipping.
- Optimizes only genuine learnable TGN parameters plus the pair-classification head.
- Uses the frozen 2018 split boundary in the study's China-local calendar and replays all canonical interactions strictly before that boundary.
- Results record `script_version=v3_tgn_optimizer_fix`.
