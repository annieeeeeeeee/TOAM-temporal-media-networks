"""EA prediction by the ORIGINAL 2026 TGFormer temporal encoder + a binary EA head.
Clones upstream repository in Colab and imports models.TGFormer.TGFormer unchanged.
Important: TGFormer upstream main.py is LINK PREDICTION and must NOT be used to score EA directly.
"""
import argparse,os,sys,time,random,importlib,traceback
from pathlib import Path
import numpy as np,pandas as pd
import torch
import torch.nn as nn
from common import assert_main_test,calc_metrics,to_json

def load_df(folder,name):
    p=Path(folder)
    if (p/(name+'.parquet')).exists():return pd.read_parquet(p/(name+'.parquet'))
    return pd.read_pickle(p/(name+'.pkl'))

def get_model(repo, raw, device, seed, neighbors):
    sys.path.insert(0,str(Path(repo).resolve()))
    from models.TGFormer import TGFormer
    from models.modules import MergeLayer
    from utils.DataLoader import Data
    from utils.utils import get_neighbor_sampler
    # Padding 0 is reserved by TGFormer; original adapter node IDs include zero.
    # Shift all actual node IDs by +1, consistently in both raw history and query tables.
    src=raw.u.to_numpy(dtype=np.int64)+1
    dst=raw.i.to_numpy(dtype=np.int64)+1
    t=raw.ts.to_numpy(dtype=np.float64)
    edges=raw.edge_id.to_numpy(dtype=np.int64)
    graph=Data(src_node_ids=src,dst_node_ids=dst,node_interact_times=t,edge_ids=edges,labels=np.zeros(len(src),dtype=np.int8))
    sampler=get_neighbor_sampler(graph,sample_neighbor_strategy='recent',seed=seed)
    # Verify strict <t history for a random node, including same-timestamp groups.
    rng=np.random.default_rng(seed)
    for ix in rng.integers(0,len(src),size=50):
        nid=int(src[ix]); ts=float(t[ix])
        nei,eids,times,_=sampler.find_neighbors_before(nid,ts)
        assert len(times)==0 or float(np.max(times))<ts
    n_nodes=int(max(src.max(),dst.max()))
    feat_dim=32  # zero node/edge features for topology/time-only baseline
    node_feat=np.zeros((n_nodes+1,feat_dim),dtype=np.float32)
    edge_feat=np.zeros((len(raw)+1,feat_dim),dtype=np.float32)
    encoder=TGFormer(node_raw_features=node_feat,edge_raw_features=edge_feat,neighbor_sampler=sampler,
        time_feat_dim=32,channel_embedding_dim=50,patch_size=1,num_layers=2,num_heads=2,dropout=0.1,
        max_input_sequence_length=neighbors,device=device,version='TGFormer').to(device)
    # Original TGFormer uses auto-correlation internally. Original pair MergeLayer,
    # but the supervision is EA label rather than source-destination link existence.
    head=MergeLayer(input_dim1=feat_dim,input_dim2=feat_dim,hidden_dim=feat_dim,output_dim=1).to(device)
    return encoder,head

def embed_logits(encoder,head, batch):
    src=batch.u.to_numpy(dtype=np.int64)+1
    dst=batch.i.to_numpy(dtype=np.int64)+1
    ts=batch.timestamp_ms.to_numpy(dtype=np.float64)/1000.0
    # Upstream TGFormer has a singleton readout squeeze(). Pad B=1 then remove duplicate result.
    singleton=len(src)==1
    if singleton:
        src=np.repeat(src,2);dst=np.repeat(dst,2);ts=np.repeat(ts,2)
    a,b=encoder.compute_src_dst_node_temporal_embeddings(src_node_ids=src,dst_node_ids=dst,node_interact_times=ts)
    logit=head(input_1=a,input_2=b).reshape(-1)
    if singleton:logit=logit[:1]
    return logit

def predict(df,enc,head,batch_size,device):
    enc.eval();head.eval(); preds=[]
    with torch.no_grad():
        for i in range(0,len(df),batch_size):
            logits=embed_logits(enc,head,df.iloc[i:i+batch_size])
            preds.append(torch.sigmoid(logits).cpu().numpy())
    return np.concatenate(preds)

def main():
    a=argparse.ArgumentParser()
    a.add_argument('--data-dir',required=True);a.add_argument('--repo',required=True);a.add_argument('--outdir',required=True)
    a.add_argument('--mode',choices=['smoke','full'],default='smoke')
    a.add_argument('--seeds',default='0')
    a.add_argument('--epochs',type=int,default=3)
    a.add_argument('--neighbors',type=int,default=10)
    a.add_argument('--batch-size',type=int,default=64)
    a.add_argument('--lr',type=float,default=1e-4)
    a.add_argument('--smoke-train',type=int,default=2048)
    a.add_argument('--smoke-test',type=int,default=1000)
    args=a.parse_args();out=Path(args.outdir);out.mkdir(parents=True,exist_ok=True)
    df=load_df(args.data_dir,'canonical_ea_features')
    raw=load_df(args.data_dir,'canonical_temporal_graph')
    assert_main_test(df)
    assert len(raw)==994890 and raw.edge_id.iloc[0]==1 and raw.edge_id.iloc[-1]==994890
    device='cuda' if torch.cuda.is_available() else 'cpu'
    print('Using',device,'original 2026 TGFormer encoder, strict historical neighboring < t',flush=True)
    rows=[]
    for seed in [int(x) for x in args.seeds.split(',')]:
        random.seed(seed);np.random.seed(seed);torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed) if torch.cuda.is_available() else None
        train=df[df.split=='train'].copy()
        test=df[df.split=='test'].copy()
        if args.mode=='smoke':
            train=train.sample(n=min(len(train),args.smoke_train),random_state=seed).sort_values('timestamp_ms',kind='stable')
            test=test.sample(n=min(len(test),args.smoke_test),random_state=seed).sort_values('timestamp_ms',kind='stable')
        enc,head=get_model(args.repo,raw,device,seed,args.neighbors)
        opt=torch.optim.AdamW(list(enc.parameters())+list(head.parameters()),lr=args.lr,weight_decay=1e-5)
        lossfn=nn.BCEWithLogitsLoss()
        start=time.time()
        for epoch in range(args.epochs):
            enc.train();head.train(); rng=np.random.default_rng(seed+1000*epoch)
            # Shuffled training queries, but every target draws neighbors strictly before t.
            idx=rng.permutation(len(train)); losses=[]
            for k in range(0,len(idx),args.batch_size):
                chunk=train.iloc[idx[k:k+args.batch_size]]
                if len(chunk)==0:continue
                y=torch.tensor(chunk.label.to_numpy(np.float32),device=device)
                opt.zero_grad(set_to_none=True)
                logits=embed_logits(enc,head,chunk)
                loss=lossfn(logits,y)
                if not torch.isfinite(loss).item():raise RuntimeError('Non-finite loss at epoch '+str(epoch))
                loss.backward();nn.utils.clip_grad_norm_(list(enc.parameters())+list(head.parameters()),1.0)
                opt.step();losses.append(float(loss.item()))
                if (k//args.batch_size+1)%200==0:print('seed',seed,'epoch',epoch+1,'batch',k//args.batch_size+1,'mean_loss',round(float(np.mean(losses)),4),flush=True)
            print('seed',seed,'epoch',epoch+1,'train_loss',round(float(np.mean(losses)),6),'elapsed_min',round((time.time()-start)/60,2),flush=True)
        prob=predict(test,enc,head,args.batch_size,device)
        rec={'model':'TGFormer-2026-EA','mode':args.mode,'seed':seed,'epochs':args.epochs,'neighbors':args.neighbors,
             'seconds':round(time.time()-start,2),**calc_metrics(test.label.to_numpy(),prob)}
        print('RESULT',rec,flush=True)
        rows.append(rec)
        pd.DataFrame({'edge_id':test.edge_id.to_numpy(),'label':test.label.to_numpy(),'probability':prob}).to_csv(out/f'TGFormer_seed{seed}_{args.mode}_pred.csv.gz',index=False,compression='gzip')
        torch.save({'encoder':enc.state_dict(),'head':head.state_dict(),'params':vars(args)},out/f'TGFormer_seed{seed}_{args.mode}.pt')
        pd.DataFrame(rows).to_csv(out/f'TGFormer_metrics_{args.mode}.csv',index=False)
        del enc,head,opt
        if torch.cuda.is_available():torch.cuda.empty_cache()
    to_json({'paper':'Chen et al. (2026), Pattern Recognition 170,112053','upstream':'https://github.com/hjchen-hdu/TGFormer',
             'task':'Canonical 3-hour EA>=2 (not link prediction)','mode':args.mode,'data':'994890 interactions,645154 labeled queries',
             'same_timestamp_rule':'sampler uses interaction timestamp < query time; all same timestamp excluded',
             'comparison_scope':'Pure temporal topology/time; no TOAM engineered feature columns used',
             'optimizer':'AdamW','epochs':args.epochs,'seeds':args.seeds,'neighbors':args.neighbors},out/'TGFormer_manifest.json')
if __name__=='__main__':main()

