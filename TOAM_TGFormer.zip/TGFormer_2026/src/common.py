import json, math, random
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score, brier_score_loss

KEYS = ['eventId', 'viewpoint_id', 'media', 'timestamp_ms']
DYNAMIC = ['age_min', 'prior_count', 'past1_count', 'past3_count', 'gap_prev_min']
SYSTEM = ['net_nodes', 'net_edges', 'net_density', 'lcc_share']
LOCAL = ['node_degree', 'prior_vp_size']
CROSS = ['weibo_a1','weibo_a3','weibo_a_momentum','weibo_b1','weibo_b3','weibo_b_momentum','weibo_total3',
         'wechat_a1','wechat_a3','wechat_a_momentum','wechat_b1','wechat_b3','wechat_b_momentum','wechat_total3']
ALL_FEATURES = DYNAMIC + ['propensity_canonical'] + SYSTEM + LOCAL + CROSS

def calc_metrics(y, p):
    y=np.asarray(y,dtype=np.int8); p=np.asarray(p,dtype=float)
    assert y.ndim==1 and p.shape==y.shape and np.isfinite(p).all()
    assert y.min()==0 and y.max()==1
    n=max(1,int(np.ceil(0.05*len(y))))
    idx=np.argsort(-p,kind='stable')[:n]
    prec=float(y[idx].mean()); rec=float(y[idx].sum()/y.sum()); base=float(y.mean())
    return dict(N=int(len(y)), positives=int(y.sum()),base_rate=base,
      PR_AUC=float(average_precision_score(y,p)),ROC_AUC=float(roc_auc_score(y,p)),
      Precision_at_5=prec, Recall_at_5=rec, Lift_at_5=prec/base,
      Brier=float(brier_score_loss(y,p)), alerts_at_5=n)

def assert_main_test(df):
    test=df[df['split']=='test']; train=df[df['split']=='train']
    if not (len(df)==645154 and len(train)==345430 and len(test)==299724 and int(test['label'].sum())==41371):
        raise ValueError(f'CANONICAL MISMATCH: all={len(df)},train={len(train)},test={len(test)},test_pos={int(test.label.sum())}; expected 645154/345430/299724/41371')
    print('CANONICAL PASS:',len(train),'train,',len(test),'test,',int(test.label.sum()),'test positives')

def to_json(obj,p):
    Path(p).write_text(json.dumps(obj,ensure_ascii=False,indent=2,default=str),encoding='utf-8')

