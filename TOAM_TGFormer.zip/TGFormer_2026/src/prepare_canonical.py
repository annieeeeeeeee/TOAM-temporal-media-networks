"""Build version-locked EA dataset using canonical GNN adapter labels.
Requirements: pandas, numpy, pyarrow. Run from project root.
"""
import argparse,zipfile,gzip, warnings
from pathlib import Path
import pandas as pd
import numpy as np
from common import KEYS,ALL_FEATURES,DYNAMIC,SYSTEM,LOCAL,CROSS,assert_main_test,to_json

def zip_csv(zip_path,name):
    with zipfile.ZipFile(zip_path) as z:
        with gzip.GzipFile(fileobj=z.open(name)) if name.endswith('.gz') else z.open(name) as f:
            return pd.read_csv(f)

def distinct_join(raw,q,name,required_columns):
    before=len(q)
    raw_dups=int(raw.duplicated(KEYS).sum())
    small=raw[KEYS+required_columns].drop_duplicates(KEYS,keep='first')
    joined=q.merge(small,on=KEYS,how='left',validate='one_to_one',sort=False,indicator=True)
    missing=int((joined['_merge']!='both').sum())
    if len(joined)!=before: raise AssertionError('JOIN ROW EXPANSION: '+name)
    joined=joined.drop(columns='_merge')
    print('Joined',name,'rows=',len(joined),'source_dup_keys=',raw_dups,'missing=',missing)
    if missing>0: raise RuntimeError(f'{name}: {missing} unmatched canonical rows; do not impute before investigating keys')
    return joined,dict(source_duplicates=raw_dups,missing=missing)

def canonical_history(df):
    """Frozen 2016-17 training-label history for holdout 2018-19; no holdout labels are used in features.
    For 2016 use constant prior 0.15; for 2017 use 2016 labels only.
    This differs slightly from legacy propensity; compare with re-trained canonical TOAM.
    """
    df['propensity_canonical']=np.float32(.15)
    for year in [2017,2018,2019]:
        hist=df.loc[(df.year>=2016)&(df.year<year)&(df.year<=2017),['media','label']]
        if hist.empty: raise AssertionError('No prior labeled training history for '+str(year))
        gp=float(hist.label.mean())
        agg=hist.groupby('media',sort=False).label.agg(['sum','count'])
        vals=((agg['sum']+10*gp)/(agg['count']+10)).to_dict()
        sel=df.year==year
        df.loc[sel,'propensity_canonical']=df.loc[sel,'media'].map(vals).fillna(gp).to_numpy(dtype=np.float32)
    return df

def main():
    a=argparse.ArgumentParser()
    a.add_argument('--adapter',required=True); a.add_argument('--time-features',required=True)
    a.add_argument('--outdir',required=True)
    arg=a.parse_args(); out=Path(arg.outdir);out.mkdir(parents=True,exist_ok=True)
    q=zip_csv(arg.adapter,'ipm_labeled_queries.csv.gz')
    assert q.edge_id.is_unique and not q.duplicated(KEYS).any(), 'Canonical query edges must be unique'
    q=q.rename(columns={'main_label':'label'});q['label']=q['label'].astype('int8');q['year']=q['year'].astype('int16')
    q=q.sort_values('edge_id',kind='stable').reset_index(drop=True)
    assert_main_test(q)
    source=zip_csv(arg.time_features,'TIME_FEATURES/main_episode_labels_propensity.csv.gz')
    # DO NOT use legacy label, EA3, expected3, future3_count or legacy propensity in the new target/features.
    df,audit_old=distinct_join(source,q,'legacy pre-entry primitives',DYNAMIC+['media_score','propensity'])
    df=df.rename(columns={'propensity':'propensity_legacy_NOT_USED'})
    del source
    net=zip_csv(arg.time_features,'TIME_FEATURES/system_network_features_all.csv.gz')
    df,audit_net=distinct_join(net,df,'network',SYSTEM+LOCAL)
    del net
    cross=zip_csv(arg.time_features,'TIME_FEATURES/crossplatform_episode_features.csv.gz')
    df,audit_cross=distinct_join(cross,df,'cross-platform',CROSS)
    del cross
    df=canonical_history(df)
    for c in ALL_FEATURES:
        df[c]=pd.to_numeric(df[c],errors='coerce')
    nan_counts=df[ALL_FEATURES].isna().sum();
    if int(nan_counts.sum())>0:
        raise ValueError('Missing predictors; do not silently fill before auditing:\n'+str(nan_counts[nan_counts>0]))
    assert df.loc[df.split=='test','label'].sum()==41371
    print('Legacy target is excluded: canonical main_label only. Full feature count',len(ALL_FEATURES))
    prepared=out/'canonical_ea_features.parquet'
    try: df.to_parquet(prepared,index=False)
    except ImportError:
        prepared=out/'canonical_ea_features.pkl'; df.to_pickle(prepared)
        print('pyarrow absent; saved pickle instead')
    # Raw temporal stream used for TGFormer: history only is accessed with timestamp < target time.
    graph=zip_csv(arg.adapter,'ipm_temporal_raw.csv.gz')
    graph['edge_id']=np.arange(1,len(graph)+1,dtype=np.int32)
    try: graph.to_parquet(out/'canonical_temporal_graph.parquet',index=False)
    except ImportError: graph.to_pickle(out/'canonical_temporal_graph.pkl')
    print('raw graph',len(graph),'range',graph.ts.min(),graph.ts.max())
    # Verify alignment from row-indexed edge IDs to raw graph at both ends and random samples.
    r=np.random.default_rng(42); ix=np.unique(np.r_[0,len(df)-1,r.choice(len(df),size=500,replace=False)])
    small=df.iloc[ix]
    g=graph.iloc[small.edge_id.to_numpy(np.int64)-1]
    assert np.array_equal(small.u.to_numpy(np.int64),g.u.to_numpy(np.int64))
    assert np.array_equal(small.i.to_numpy(np.int64),g.i.to_numpy(np.int64))
    assert np.allclose(small.timestamp_ms.to_numpy(np.float64)/1000,g.ts.to_numpy(np.float64),atol=0.01,rtol=0)
    audit={'canonical_all':len(df),'canonical_train':int((df.split=='train').sum()),'canonical_test':int((df.split=='test').sum()),'canonical_test_positive':41371,'graph_edges':len(graph),'primitive_join':audit_old,'network_join':audit_net,'cross_join':audit_cross,'feature_count':len(ALL_FEATURES),'features':ALL_FEATURES,
      'propensity':'Frozen test: fitted from 2016-2017 canonical labels only; training 2017 uses 2016 only; 2016 prior=0.15',
      'warning':'Legacy EA3 and label disagree with canonical labels on a nontrivial subset; never mix targets.'}
    to_json(audit,out/'data_audit.json');print('SAVED',out)
if __name__=='__main__': main()

