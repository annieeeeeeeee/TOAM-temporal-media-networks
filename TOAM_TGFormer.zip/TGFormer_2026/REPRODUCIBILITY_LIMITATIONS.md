# Requirements for full independent reproduction

The released numerical results and source scripts alone do NOT constitute a complete standalone reproduction bundle. Before describing this repository as containing all data and implementations, please supply / document:

1. The canonical adapter archive `IPM_DyGLib_official_baseline_adapter_v1.zip` including `ipm_labeled_queries.csv.gz`, `ipm_temporal_raw.csv.gz` or a rights-compliant route to obtain them.
2. The time-feature archive `IPM_research_data_04_time_features.zip` including the exact feature CSVs used by `prepare_canonical.py`. The pipeline reads only pre-entry primitives; the *legacy labels* in that archive must NOT be used as the EA target.
3. The exact upstream TGFormer git commit SHA as recorded by the original run (`TGFormer_upstream_commit.txt`); not currently supplied with this bundle.
4. Python/PyTorch/CUDA and package versions of the actual five-seed run, random seeds and hardware. The provided requirements are ranges from the source notebook, not a frozen lockfile.
5. Ideally, original prediction files (`TGFormer_seed*_full_pred.csv.gz`) or checksums, training logs and each seed's saved model parameters. These were **not** available for inclusion here.
6. The four previously described main-paper packages (`CoreData.zip`, `TimeFeatures.zip`, `CanonicalGNNAdapter.zip`, `GNNRunCode.zip`) if publication rights allow, or a precise access restriction and reproduction process. They are not in the current public repository as of 2026-10-09.

Do not upload user-specific Google Drive tokens, private datasets without redistribution permission, author-identifying correspondence, or the manuscript preprint during double-blind review. Source terms may constrain disclosure of event-level records.
