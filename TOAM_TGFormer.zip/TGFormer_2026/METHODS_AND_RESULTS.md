# TGFormer (2026): canonical excess-amplification comparison

**Study**: *Who Matters, and When? Explainable Prediction of Excess Amplification in Temporal Media Networks*

**Literature**: Chen, H., Jiao, P., Du, M., Guo, X., Zhao, Z., Jin, D., & Liu, X. (2026). TGFormer: Towards temporal graph transformer with auto-correlation mechanism. *Pattern Recognition*, **170**, 112053. https://doi.org/10.1016/j.patcog.2025.112053

Upstream model repository: https://github.com/hjchen-hdu/TGFormer

## Evaluation protocol

- Target: 3-hour Excess Amplification (EA ≥ 2), with expected future diffusion estimated from **pre-entry** trajectories.
- Sample universe: 6,021 events; 994,890 unique first-adoption interactions; 645,154 labeled situations.
- Chronological training: 2016–2017, 345,430 situations.
- Chronological testing: 2018–2019, 299,724 situations, 41,371 positives.
- Five random seeds: 0, 1, 2, 3, 4; five epochs; 10 strictly historical neighbors.
- Strict temporal boundary: historical interactions used at time t satisfy τ < t. All equal-timestamp interactions are excluded from each other's pre-entry state.
- Features: temporal interaction topology/time only (zero raw node/edge features); the same EA labels and chronological split as TOAM.
- Learning: original TGFormer temporal encoder adapted with a binary EA prediction head; not the upstream link-prediction task.
- Reported standard deviations are **population SD** over five seeds (ddof=0).

## Frozen results

| Metric | Five-seed mean | SD (population) |
|---|---:|---:|
| PR-AUC | 0.307392 | 0.005160 |
| ROC-AUC | 0.708231 | 0.005613 |
| Precision@5% | 0.448709 | 0.008204 |
| Recall@5% | 0.162549 | 0.002972 |
| Lift@5% | 3.250799 | 0.059437 |
| Brier | 0.110019 | 0.000734 |

Five individual results and their summary: `results/TGFormer_5seed_metrics.csv` and `results/TGFormer_5seed_summary.csv`.

**Scope of inference.** On this specific canonical EA task and evaluation protocol, TGFormer scores below TOAM (PR-AUC = 0.370027) and GraphMixer (mean PR-AUC = 0.335857). This is not a general claim that one architecture is universally superior.

## Evidence limitations

The CSVs reproduce the **reported numeric results** from the formally supplied handoff workbook; they are not freshly rerun in this package. The Python files were extracted verbatim from the supplied Colab source cells and passed syntax compilation, but no end-to-end rerun was possible without the required input archives and the upstream pinned commit. There is no guarantee that the included scripts match the precise historical runtime commit until those artifacts are supplied and verified.
