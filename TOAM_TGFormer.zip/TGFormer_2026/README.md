# TGFormer (2026) EA baseline

This folder provides the *additional* temporal-graph baseline for the TOAM manuscript.

- `src/`: canonical-data preparation, shared evaluation functions, and adapted official TGFormer encoder with EA prediction head. These files were extracted from the supplied source Colab notebook and syntax-checked. They have **not** been independently rerun here.
- `TGFormer_EA_reproduction.ipynb`: optional Colab workflow. Requires two separate authorized input archives (see `REPRODUCIBILITY_LIMITATIONS.md`).
- `results/`: official handoff five-seed metrics and population-SD summary for the frozen canonical task.
- `METHODS_AND_RESULTS.md`: task, split, temporal rule, parameters, numerical results and proper reference.
- `requirements.txt`: approximate package ranges (not a full locked environment).

**Do not use legacy labels or smoke results** as replacements for published canonical scores. Do not claim fully standalone reproduction until the listed data and provenance artifacts are available.
