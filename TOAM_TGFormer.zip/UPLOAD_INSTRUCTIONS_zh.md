# GitHub 上传说明（仅新增 TGFormer 复现材料）

目标仓库：https://github.com/annieeeeeeeee/TOAM-temporal-media-networks

## 立即可上传

将本包中的 `TGFormer_2026/` 整个文件夹放在仓库根目录。公开内容包括：适配源码、准备数据的脚本、Colab Notebook、五轮正式实验指标CSV、汇总CSV、方法与限制说明。

本包**没有**原始/重构时序网络数据、旧四种GNN的训练包、原始五轮预测文件、历史运行时准确commit及环境锁文件，因此不能宣称“全部可独立复现”。源代码来自用户历史 Colab 笔记本（已经通过Python语法检查，但未重新跑完整任务）。

## 同时修正仓库当前误导性描述

仓库目前（2026-10-09）只有 `.gitignore`、`README.md`、`DATA_AND_CODE_AVAILABILITY.md`、`LICENSE`，没有 README 中声称已经发布的四个 ZIP 文件。建议把已有 README 和 DATA_AND_CODE_AVAILABILITY.md 中声称已经公开四包的陈述调整为条件性说明。

如果你已经拥有并有权公开这四个包，请在上传后再恢复“released”措辞。没有数据再分发权时，不要强行上传：改为明确 access restrictions / available upon reasonable request, where permitted。

`README_REPLACEMENT.md` 和 `DATA_AND_CODE_AVAILABILITY_REPLACEMENT.md` 提供更符合现状的建议文字。你可手动复制粘贴到仓库对应文件。**本次没有直接修改远程 GitHub。**

## 上传前核验

1. 确认代码中没有 token、Drive credential、受限数据内容或暴露作者身份的路径。
2. 如能找到真实运行的 `TGFormer_upstream_commit.txt`、环境版本和预测文件，应作为后续补充材料。
3. 更新论文的 Data and Code Availability，使“已公开”的范围和当前仓库保持一致；Response to the Editor 的双盲声明应避免未经核实的“匿名”保证。
4. 不上传完整论文 Word/PDF 预印本，避免违反本次初审明确要求。
