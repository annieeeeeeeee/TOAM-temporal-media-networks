# Data and Code Availability — verified status

The accompanying repository contains analysis documentation and an additional TGFormer (2026) EA-adaptation code and five-seed metrics release. The canonical data, TOAM feature files, and original four-baseline experimental packages are not currently uploaded here. Some underlying records originate from third-party sources and may be subject to redistribution restrictions. Full independent replication additionally requires authorized access to the canonical data archives and the precise upstream TGFormer software/environment versions described in `TGFormer_2026/REPRODUCIBILITY_LIMITATIONS.md`.

Repository: https://github.com/annieeeeeeeee/TOAM-temporal-media-networks

Suggested **manuscript** statement if the data packages remain unavailable:

> The repository provides the TGFormer baseline adaptation, five-seed evaluation summaries, and associated reproduction instructions. The underlying processed event records, time-indexed features, and parts of the standardized baseline inputs are derived from third-party materials and are not currently distributed through the repository. Access and redistribution of these materials are subject to the applicable source terms. The reproducibility notes specify the required inputs and the limitations of the released package.

Revise this statement to reflect only resources actually present when you submit; do not claim full open availability while files remain absent.
