# TOAM — Temporal Opportunity-Aware Amplification in Temporal Media Networks

Reproducibility resources associated with the submission *Who Matters, and When? Explainable Prediction of Excess Amplification in Temporal Media Networks*.

## Resources currently included

- [`TGFormer_2026/`](TGFormer_2026/): TGFormer (2026) EA-adaptation scripts, Colab workflow, five-seed summary metrics, and reproducibility notes.
- `LICENSE`: repository code-license terms; rights in any third-party data remain with the original providers.

## Data and baseline package availability

The main analysis uses an event-level dataset, canonical first-adoption graph records, temporal features, and standardized baseline adapters. Some of these resources derive from third-party data and cannot be assumed redistributable. At the time of this update, this repository does **not** contain the previously described `CoreData.zip`, `TimeFeatures.zip`, `CanonicalGNNAdapter.zip`, and `GNNRunCode.zip` packages. Their future release is subject to source terms and verification of distributable content.

See [`TGFormer_2026/REPRODUCIBILITY_LIMITATIONS.md`](TGFormer_2026/REPRODUCIBILITY_LIMITATIONS.md) for the exact data archives, upstream version and experimental outputs needed for a complete independent reproduction.

## Main experimental scope

- 6,021 events; 994,890 first-adoption interactions.
- 645,154 labeled media–viewpoint–event–time situations.
- Training 2016–2017: 345,430; testing 2018–2019: 299,724; test positives: 41,371.
- Excess Amplification (EA): observed future diffusion minus the expectation estimated **only from the pre-entry trajectory**.
- Main specification: 3-hour future horizon; EA ≥ 2; strict historical information τ < t, with same-timestamp batch predict-before-update.

The TGFormer comparison is task-specific and makes no claim of universal architectural superiority.

**Submission anonymity:** This repository contains no manuscript preprint. Authors should separately confirm that account history, repository metadata and any code comments cannot reveal their identities during double-blind review.
